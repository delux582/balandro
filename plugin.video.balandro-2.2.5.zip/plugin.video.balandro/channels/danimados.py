# -*- coding: utf-8 -*-

import re

from platformcode import logger, platformtools
from core.item import Item
from core import httptools, scrapertools, servertools, tmdb


host = 'https://www.d-animados.com/'


def mainlist(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar ...', action = 'search', search_type = 'all', text_color = 'yellow' ))

    itemlist.append(item.clone( title = 'Películas', action = 'mainlist_pelis', text_color = 'deepskyblue' ))
    itemlist.append(item.clone( title = 'Series', action = 'mainlist_series', text_color = 'hotpink' ))
    itemlist.append(item.clone( title = 'Animes', action = 'mainlist_animes', text_color = 'springgreen' ))


    return itemlist


def mainlist_pelis(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar película ...', action = 'search', search_type = 'movie', text_color = 'deepskyblue' ))

    itemlist.append(item.clone( title = 'Catálogo', action = 'list_all', url = host + 'peliculas/', search_type = 'movie' ))

    return itemlist


def mainlist_series(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar serie ...', action = 'search', search_type = 'tvshow', text_color = 'hotpink' ))

    itemlist.append(item.clone( title = 'Catálogo', action ='list_all', url = host + 'series/', search_type = 'tvshow' ))

    return itemlist


def mainlist_animes(item):
    logger.info()
    itemlist = []

    itemlist.append(item.clone( title = 'Buscar anime ...', action = 'search', search_type = 'tvshow', text_color = 'springgreen' ))

    itemlist.append(item.clone( title = 'Catálogo', action ='list_all', url = host + 'tag/anime/', search_type = 'all' ))

    return itemlist


def list_all(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    bloque = scrapertools.find_single_match(data, '</h1>(.*?)$')

    matches = re.compile('<article(.*?)</article>', re.DOTALL).findall(bloque)

    for match in matches:
        url = scrapertools.find_single_match(match, '<a href="(.*?)"')
        title = scrapertools.find_single_match(match, 'alt="(.*?)"')

        if not url or not title: continue

        thumb = scrapertools.find_single_match(match, 'data-src="(.*?)"')

        year = scrapertools.find_single_match(match, '<span class=Year>(.*?)</span>').strip()
        if not year: year = scrapertools.find_single_match(match, '<span class="year">(.*?)</span>').strip()
        if not year: year = '-'

        qlty = scrapertools.find_single_match(match, '<span class=Qlty>(.*?)</span>').strip()
        if not qlty: qlty = scrapertools.find_single_match(match, '<span class="Qlty">(.*?)</span>').strip()

        plot =  scrapertools.find_single_match(match, '<p>(.*?)</p>')

        tipo = 'tvshow' if '/series/' in url else 'movie'
        sufijo = '' if item.search_type != 'all' else tipo

        if '/movies/' in url:
            if item.search_type == 'tvshow': continue

            if tipo == 'tvshow': continue

            itemlist.append(item.clone( action='findvideos', url=url, title=title, thumbnail=thumb, fmt_sufijo=sufijo, languages='Lat', qualities=qlty,
                                        contentType='movie', contentTitle=title, infoLabels={'year': year, 'plot': plot} ))

        if '/series/' in url:
            if item.search_type == 'movie': continue

            if tipo == 'movie': continue

            itemlist.append(item.clone( action='temporadas', url = url, title = title, thumbnail = thumb, fmt_sufijo=sufijo, languages='Lat', qualities=qlty,
                                        contentType='tvshow', contentSerieName=title, infoLabels={'year': year, 'plot': plot} ))

    tmdb.set_infoLabels(itemlist)

    if itemlist:
        next_page = scrapertools.find_single_match(data, '<a class="page-link current".*?">.*?</a> <a href="(.*?)"')
        if next_page:
            if '/page/' in next_page:
                itemlist.append(item.clone( title='Siguientes ...', url = next_page, action='list_all', text_color='coral' ))

    return itemlist


def temporadas(item):
    logger.info()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    temporadas = re.compile('</figure><div><p>Temporada.*?<span>(.*?)</span>', re.DOTALL).findall(data)

    for tempo in temporadas:
        tempo = tempo.strip()
        title = 'Temporada ' + tempo

        if len(temporadas) == 1:
            platformtools.dialog_notification(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), 'solo [COLOR tan]' + title + '[/COLOR]')
            item.contentType = 'season'
            item.contentSeason = tempo
            itemlist = episodios(item)
            return itemlist

        itemlist.append(item.clone( action = 'episodios', title = title, contentType = 'season', contentSeason = tempo ))

    tmdb.set_infoLabels(itemlist)

    return itemlist


# ~ def tracking_all_episodes(item):
# ~     return episodios(item)


def episodios(item):
    logger.info()
    itemlist = []

    if not item.page: item.page = 0
    if not item.perpage: item.perpage = 50

    data = httptools.downloadpage(item.url).data

    bloque = scrapertools.find_single_match(data, "</figure><div><p>Temporada.*?<span>" + str(item.contentSeason) + "</span>(.*?)" + '<div class="tags">')

    matches = re.compile('<figure(.*?)</div></div>', re.DOTALL).findall(bloque)

    if item.page == 0:
        sum_parts = len(matches)
        if sum_parts > 250:
            if platformtools.dialog_yesno(item.contentSerieName.replace('&#038;', '&').replace('&#8217;', "'"), '¿ Hay [COLOR yellow][B]' + str(sum_parts) + '[/B][/COLOR] elementos disponibles, desea cargarlos en bloques de [COLOR cyan][B]250[/B][/COLOR] elementos?'):
                platformtools.dialog_notification('Danimados', '[COLOR cyan]Cargando elementos[/COLOR]')
                item.perpage = 250

    i = 0

    for match in matches[item.page * item.perpage:]:
        i += 1

        url = scrapertools.find_single_match(match, '<a href="(.*?)"')
        title = scrapertools.find_single_match(match, '<h3 class="title"><span>.*?</span>(.*?)</h3>').strip()

        thumb = scrapertools.find_single_match(match, 'src="(.*?)"')

        episode = i

        titulo = str(item.contentSeason) + 'x' + str(i) + ' ' + title

        itemlist.append(item.clone( action='findvideos', url = url, title = titulo, thumbnail=thumb,
                                    contentType = 'episode', contentSeason = item.contentSeason, contentEpisodeNumber=episode ))

        episode = i

        if len(itemlist) >= item.perpage:
            break

    if itemlist:
        if len(matches) > ((item.page + 1) * item.perpage):
            itemlist.append(item.clone( title="Siguientes ...", action="episodios", page = item.page + 1, perpage = item.perpage, text_color='coral' ))

    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []

    if not item.url: return itemlist

    data = httptools.downloadpage(item.url).data

    matches = re.findall('<span class="num">OPCIÓN <span>.*?src="(.*?)"', data, flags=re.DOTALL)

    ses = 0

    for link in matches:
        data = httptools.downloadpage(link, headers = {'Referer': item.url}).data

        url = scrapertools.find_single_match(data, '<div class="Video">.*?src="(.*?)"')

        if url:
            data2 = httptools.downloadpage(url, headers = {'Referer': item.url}).data

            links = re.findall("go_to_player.*?'(.*?)'", data2, flags=re.DOTALL)

            for url in links:
                ses += 1

                if '/hqq.' in url or '/waaw.' in url or '/netu.' in url:
                    ses = ses -1
                    continue

                servidor = servertools.get_server_from_url(url)
                servidor = servertools.corregir_servidor(servidor)

                servidor = servertools.corregir_servidor(servidor)

                other = ''
                if servidor == 'directo':
                   if '/player' in url: other = 'Player'
                   elif '/sbfast' in url: other = 'Sbfast'

                itemlist.append(Item( channel = item.channel, action = 'play', server = servidor, language = 'Lat', title = '', url = url, other = other )) 

    if not itemlist:
        if not ses == 0:
            platformtools.dialog_notification(config.__addon_name, '[COLOR tan][B]Sin enlaces Soportados[/B][/COLOR]')
            return

    return itemlist


def play(item):
    logger.info()
    itemlist = []

    url = item.url

    if item.server == 'directo':
        data = httptools.downloadpage(url).data

        url = scrapertools.find_single_match(data, '"embed_url":"(.*?)"')

        if not url:
            if 'function runPlayer' in data:
                api = scrapertools.find_single_match(data, 'function runPlayer.*?url:.*?"(.*?)"')
                if api.startswith('//'): api = 'https:' + api

                if api:
                    data_api = httptools.downloadpage(api).data

                    srv = scrapertools.find_single_match(str(data_api), '"host":"(.*?)"')

                    if srv == 'mediafire':
                        return 'Servidor Mediafire [COLOR tan]No soportado[/COLOR]'

                    url = scrapertools.find_single_match(str(data_api), '"id":"(.*?)"')
                    #if not url: url = scrapertools.find_single_match(str(data_api), '"file":"(.*?)"')

                    if srv == 'videobin': url = 'https://videobin.co/' + url

                    url = url.replace('\\/', '/')

                    if url.startswith('//'): url = 'https:' + url

    if url:
        if '/hqq.' in url or '/waaw.' in url or '/netu.' in url:
            return 'Requiere verificación [COLOR red]reCAPTCHA[/COLOR]'

        servidor = servertools.get_server_from_url(url)
        servidor = servertools.corregir_servidor(servidor)

        itemlist.append(item.clone(server = servidor, url = url))

    return itemlist


def search(item, texto):
    logger.info()
    itemlist = []

    try:
        item.url =  host + '?s=' + texto.replace(" ", "+")
        return list_all(item)
    except:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)

    return itemlist
